//
//  main.m
//  UDPServer
//
//  Created by caokun on 16/8/25.
//  Copyright © 2016年 caokun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
