# GCDAsyncUdpSocket-demo
UDP 协议的例子

AsyncUdpSocket 框架的一个例子

分别启动两个项目，就可以在控制台看到两个APP用udp协议在通信啦

